package by.wlad.koshelev.apexlegendstracker.GamerStats


import com.google.gson.annotations.SerializedName

data class MetadataXXXXXXXXXX(
    @SerializedName("iconUrl")
    var iconUrl: String,
    @SerializedName("rankName")
    var rankName: String
)