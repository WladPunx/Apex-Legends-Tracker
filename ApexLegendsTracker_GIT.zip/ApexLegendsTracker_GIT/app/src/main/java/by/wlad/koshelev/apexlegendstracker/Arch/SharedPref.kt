package by.wlad.koshelev.apexlegendstracker.Arch

import android.content.SharedPreferences


object SharedPref {
    lateinit var myShar: SharedPreferences
    val APP_PREFERENCES = "mysettings"
    val style = "style"
}