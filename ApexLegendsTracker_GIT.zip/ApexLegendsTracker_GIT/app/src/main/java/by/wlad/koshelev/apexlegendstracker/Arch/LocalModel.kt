package by.wlad.koshelev.apexlegendstracker.Arch

class LocalModel {
}