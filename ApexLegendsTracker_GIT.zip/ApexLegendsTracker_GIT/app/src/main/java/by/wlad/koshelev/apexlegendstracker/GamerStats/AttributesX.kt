package by.wlad.koshelev.apexlegendstracker.GamerStats


import com.google.gson.annotations.SerializedName

data class AttributesX(
    @SerializedName("id")
    var id: String
)